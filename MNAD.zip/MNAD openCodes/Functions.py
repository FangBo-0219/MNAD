import numpy as np
import pylab as pl
from scipy import fftpack
import tensorflow as tf


def funcSpectrum(signal, fs, title, halffilterL):
    signal = signal[halffilterL:-halffilterL]
    N = len(signal)
    f = np.arange(0, N) / N * fs
    mag = fftpack.fft(signal)
    mag = abs(mag)
    mag = mag / max(mag)
    pl.figure(figsize=(6, 4))
    pl.plot(f, mag)
    pl.xlim([0, fs / 2])
    pl.title(title)
    pl.xlabel('Frequency(Hz)')
    pl.ylabel('Acc(normalized)')


def funcEnv_Es(signal, title, Fs, xLim, esLim):
    signal = signal / abs(np.max(signal))
    a_signal_raw = fftpack.hilbert(signal)
    hx_raw_abs = abs(a_signal_raw)
    hx_raw_abs1 = hx_raw_abs - np.mean(hx_raw_abs)
    es_raw = fftpack.fft(hx_raw_abs1, len(signal))
    es_raw_abs = abs(es_raw)
    es_raw_abs = es_raw_abs / max(es_raw_abs)

    t1 = (np.arange(0, len(signal))) / Fs
    f1 = t1 * Fs * Fs / len(signal)
    pl.figure(figsize=(6, 8))
    pl.subplots_adjust(hspace=0.35, wspace=0.3)
    pl.subplot(211)
    pl.plot(t1, signal)
    pl.xlim(xLim)
    pl.title('zoom of ' + title)
    pl.xlabel('Time(s)')
    pl.ylabel('Acc(normalized)')
    pl.subplot(212)
    pl.plot(f1, es_raw_abs)
    pl.title('Envelope spectrum of ' + title)
    pl.xlabel('Frequency(Hz)')
    pl.ylabel('Acc(normalized)')
    pl.xlim(esLim)


def findNoisePso(filter_len, signal, T, N):
    # Parameter interpretation
    #  filterLen : Filter length
    #  signalRaw :  One-dimensional acceleration signalRaw to be processed
    #  T :  Period of fault pulse (number of points)
    #  N :  N consecutive points are judged as noise.
    start = filter_len * 0.33
    end = len(signal) - filter_len * 1 - 1
    T1 = []
    while start <= end:
        m = np.round(start)
        for i in range(N):
            index = np.round(m + i)
            if index <= end:
                T1.append(index)
            else:
                break
        start += T
    return tf.cast(T1, dtype=tf.int32)


#  Initialize all filter coefficients randomly
def initializeCoefficients(layersNum, filterSize):
    # Parameter interpretation
    #  layersNum : Number of convolution filters
    #  filterSize : Filter length
    weights = {}
    random_normal = tf.initializers.RandomNormal()
    for i in range(layersNum):
        layerName = 'wc%d' % (i + 1)
        weights[layerName] = tf.Variable(random_normal([filterSize, 1, 1]))
    return weights


def PNAR(y, T1, halffilterL):
    y_1 = tf.squeeze(y)
    y_1 = y_1[halffilterL:-halffilterL]
    y_2 = y_1 - tf.reduce_mean(y_1)
    y_3 = tf.gather(y_2, T1)
    N = len(y_3)
    y_4 = tf.reduce_sum(tf.math.abs(y_3)) / N * np.sqrt(len(y_2))
    loss = y_4 / tf.norm(y_2, 2)
    return loss


# Forward filtering
def forwardFiltering(x, layersNum, num, coeffs):
    # Parameter interpretation
    #  x : One dimensional signalRaw
    #  layersNum : Number of convolution filters
    #  num : length of x
    #  coeffs : the coefficients of all convolution filters
    x = tf.reshape(x, [1, num, 1])
    conv1 = x
    for i in range(layersNum):
        conv1 = conv1d(conv1, coeffs['wc%d' % (i + 1)])
    return conv1


# Convolution filtering using tensorflow  framework.
def conv1d(x, W):
    # Parameter interpretation
    #  x : One dimensional signalRaw
    #  W : Filter coefficients
    x = tf.nn.conv1d(x, W, stride=[1, 1, 1], padding='SAME')
    return x
