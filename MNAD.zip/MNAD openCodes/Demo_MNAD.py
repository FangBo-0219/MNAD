# Python implementation of MNAD
#
# The GPU model is 1050Ti and the CPU model is I5-8300HQ. The author uses tensorFlow 2.1-GPU. Compared with the
# implementation of MATLAB, this implementation is significantly faster and may obtain better performance. Please
# refer to my MATLAB implementation for more examples which can be downloaded from the MATLAB community.
#
# Related article: Minimum noise amplitude deconvolution and its application in repetitive impact detection.
# Structural Health Monitoring,2022 accepted.
#
# Bo Fang, 2022 05 20.  Research Center of Condition Monitoring and Fault Diagnosis,Southeast University.
# 130549962@qq.com

# The datasets are provided by Case Western Reserve University Bearing Data Center Website
# 〈http://csegroups.case.edu/bearingdatacenter/home〉.


#  --------------------------------------------------Import related packages--------------------------------------------
import time
import tensorflow as tf
import numpy as np
import pylab as pl
import Functions as fun_FangBo

#  ----------------------------------------------------parameters  -----------------------------------------------------
fs = 12000  # sampling frequency
BPFI = 162.2  # fault characteristic frequency
num = 12000 * 3  # signal length
filterSize = 400  # filter length

rho = 0.6  # noise ratio
iter = 200  # number of iterations

testNum = 2  # Number of tests
learningRate = 0.01  # learning rate
layersNum = 1  # number of layers of BADBD

#  ---------------------------------------Load testing signals and format conversion -----------------------------------
file = 'X105_BA_time.txt'
signalAll = []
for line in open(file, "r"):
    point = float(line)
    signalAll.append(point)
signal = signalAll[0: 0 + num]

T = fs / BPFI
N = round(rho * T)
T1 = fun_FangBo.findNoisePso(filterSize, signal, T, round(rho * T))

signal_f = tf.cast(signal, dtype=tf.float32)
signalR = tf.reshape(signal_f, [1, num, 1])

#  -------------------------------------------Define a single iteration process ----------------------------------------
coeffs = fun_FangBo.initializeCoefficients(layersNum, filterSize)  # Initialize all filter coefficients randomly
optimizer = tf.optimizers.Adam(learningRate)  # ADAM


def singleOptimization(signalR):  # Single iteration function
    with tf.GradientTape() as g:
        y = fun_FangBo.forwardFiltering(signalR, layersNum, num, coeffs)
        loss = fun_FangBo.PNAR(y, T1, tf.dtypes.cast(filterSize / 2, tf.int32))
    trainable_variables = list(coeffs.values())
    gradients = g.gradient(loss, trainable_variables)
    optimizer.apply_gradients(zip(gradients, trainable_variables))
    return y, loss


#  ---------------------------------------------------------MNAD -------------------------------------------------------
PNAR_vec = np.empty([testNum, iter + 1])
signals_outputs = np.empty([testNum, len(signal)])

start = time.time()
for n in range(testNum):
    for step in range(iter + 1):
        y_out, loss = singleOptimization(signalR)
        PNAR_vec[n, step] = loss
    signals_outputs[n, :] = tf.squeeze(y_out)

    random_normal = tf.initializers.RandomNormal()
    for i in coeffs.keys():
        coeffs[i] = tf.Variable(random_normal([filterSize, 1, 1]))

run_time = time.time() - start

#  -------------------------------------------------------Results ------------------------------------------------------
print("calculation time:", run_time)
if type(signal) != list:
    signalRaw = signal.numpy()
else:
    signalRaw = signal

print("PNARs of filtered signals：", PNAR_vec[:, iter])
print("Average value of PNARs：", tf.reduce_mean(PNAR_vec[:, iter]))

fun_FangBo.funcSpectrum(signalRaw, fs, 'spectrum of raw signal', tf.dtypes.cast(filterSize / 2, tf.int32))
fun_FangBo.funcEnv_Es(signalRaw, 'raw signal ', fs, [1, 1.2], [0, 1000])

for i in range(testNum):
    fun_FangBo.funcSpectrum(signals_outputs[i, :], fs, 'spectrum of filtered signal',
                            tf.dtypes.cast(filterSize / 2, tf.int32))
    fun_FangBo.funcEnv_Es(signals_outputs[i, :], 'filtered signal ', fs, [1, 1.2], [0, 1000])
    pl.figure()
    pl.plot(PNAR_vec[i, :], 'b')
    pl.xlabel('iteration-%d' % i)
    pl.ylabel('PNAR')

pl.show()
